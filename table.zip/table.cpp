#include<iostream>
using namespace std;
int main()
{
	int num1;
	int table[]={1,2,3,4,5,6,7,8,9,10};
	int n=10;
	cout<<"enter the number";
	cin>>num1;
	for(int i=1;i<=n;i++)
	{
		
		cout<<num1*i<<endl;
	}
	return 0;
}
