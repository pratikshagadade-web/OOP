#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	int num1,num2;
	cout<<"enter the first number";
	cin>>num1;
	cout<<"enter the secound number";
	cin>>num2;
	char option;
	cout<<"enter the airthmatic opertion"<<endl<<"1st addition"<<endl<<"2nd substraction"<<endl<<"3rd multiplication"<<endl<<"4th division ";
	cin>>option;
	switch(option)
	{
	case'+':
        cout<<"the addition is:"<<num1+num2;
		break;
	case'-':
	 	cout<<"substraction is:"<<num1-num2;
	 	break;
    case'*':
    	cout<<"the multiplication is:"<<num1*num2;
    	break;
    case'/':
    	cout<<"the division is:"<<num1/num2;
    	break;
    default:
    	cout<<"the option is noy valid";
    	break;
    
	}
   return 0;	
}
