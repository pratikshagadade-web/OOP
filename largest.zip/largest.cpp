#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	int a,b,c;
	cout<<"enter three numbers";
	cin>>a;
	cin>>b;
	cin>>c;
	if(a>b)
	{
		if(a>c)
		{
	 		cout<<"first number is largest";
	 	}
	 	else
	 	{
	   		cout<<"third number is largest";
		}
	}
	else if(b>c)
	{
		cout<<"second number is largest";
	}
	else
	{
		cout<<"third number is largest";
	}
	return 0;
}
